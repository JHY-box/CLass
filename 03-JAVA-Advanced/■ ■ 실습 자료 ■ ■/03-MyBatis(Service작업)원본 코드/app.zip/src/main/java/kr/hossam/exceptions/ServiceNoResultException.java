package kr.hossam.exceptions;

public class ServiceNoResultException extends Exception {
    public ServiceNoResultException(String message) {
        super(message);
    }
}
